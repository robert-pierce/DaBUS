========================================
 CS 2200 LC-2200 32-bit assembler 
========================================

To build this assembler:
	1) Open a terminal and navigate to this directory
	2) Type 'make'
	3) This should compile the assembler into assemble32
		(might need to type 'chmod a+x assemble32')
	
To use:
	1) ./assemble32 file.s
		
		Will output file.lc, which you can then test on your datapath
                by copy and pasting the contents into the Logism memory RAM.
